package com.example.sang.bakingapp.ui;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.sang.bakingapp.R;
import com.example.sang.bakingapp.modal.Steps;

import java.util.List;

public class RecipeStepsFragment extends Fragment implements StepAdapter.OnStepClickListener {



    private List<Steps> mSteps;


    public void setmSteps(List<Steps> mSteps) {
        this.mSteps = mSteps;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        Context context = getContext();
        View listLayout = inflater.inflate(R.layout.fragment_recipe_steps, container ,false);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(context ,LinearLayoutManager.VERTICAL ,false);
        RecyclerView mRecyclerView = listLayout.findViewById(R.id.rv_recipe_step_list);

        mRecyclerView.setLayoutManager( linearLayoutManager );
        StepAdapter stepAdapter = new StepAdapter(mSteps , context , this);
        mRecyclerView.setAdapter( stepAdapter );

        return listLayout;
    }

    @Override
    public void onStepClick(Steps lSteps) {

        Log.d("Clicked step " , lSteps.getDescription());
    }
}
