package com.example.sang.bakingapp.ui;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.sang.bakingapp.R;
import com.example.sang.bakingapp.modal.Steps;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class StepAdapter extends RecyclerView.Adapter<StepAdapter.StepsViewHolder>{

    private List<Steps> mSteps;
    private Context context;
    private OnStepClickListener stepClickHandler;

    public StepAdapter(List<Steps> mSteps, Context context ,OnStepClickListener onStepClickListener) {
        this.mSteps = mSteps;
        this.context = context;
        this.stepClickHandler = onStepClickListener;
    }

    @NonNull
    @Override
    public StepsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        int idItem = R.layout.list_recipe_step_item;

        LayoutInflater inflater = LayoutInflater.from(context);

        boolean shouldAttachToParentImmediately = false;
        View view = inflater.inflate(idItem , parent , shouldAttachToParentImmediately);
        return new StepsViewHolder( view );
    }

    @Override
    public void onBindViewHolder(@NonNull StepsViewHolder holder, int position) {

        int stepNo = (position + 1);
        holder.tvStepNo.setText( String.valueOf(stepNo) );
        holder.tvStepLabel.setText(mSteps.get(position).getShortDescription());
    }

    @Override
    public int getItemCount() {
        if(mSteps != null)
        return mSteps.size();

        return 0;
    }

    interface OnStepClickListener{
        public void onStepClick(Steps lSteps);
    }


    class StepsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        @BindView(R.id.tv_step_no)
        TextView tvStepNo;
        @BindView(R.id.tv_step_label)
        TextView tvStepLabel;

        public StepsViewHolder(View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
           itemView.setOnClickListener( this );
        }

        @Override
        public void onClick(View v) {
            int i = getAdapterPosition();
            Steps s = mSteps.get(i);
            stepClickHandler.onStepClick( s );
        }
    }
}
